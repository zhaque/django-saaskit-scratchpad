=======================
django_threadedcomments
=======================

This is a simple yet flexible threaded commenting system for your Django 
projects.

For installation instructions, see the file "INSTALL.txt" in this
directory; for a tutorial on how to set up this system with a blog, see 
"docs/tutorial.txt".  For an API reference, see "docs/api.txt".

Visit the google code page at http://django-threadedcomments.googlecode.com/